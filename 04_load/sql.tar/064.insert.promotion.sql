INSERT INTO tpcds.promotion SELECT * FROM ext_tpcds.promotion;
