INSERT INTO tpcds.catalog_returns SELECT * FROM ext_tpcds.catalog_returns;
